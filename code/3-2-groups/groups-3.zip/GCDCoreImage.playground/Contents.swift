import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true
// 1
var view = ImageViews(frame: CGRect(x: 0, y: 0, width: 400, height: 400))
view.backgroundColor = UIColor.orange
PlaygroundPage.current.liveView = view

let filter = ImageFilter()
let filterGroup = DispatchGroup()
let globalQueue = DispatchQueue.global(qos: .utility)
let imageNamesArray = ["image1.jpg", "image2.jpg", "image3.jpg", "image4.jpg"]
var imageArray = [UIImage]()

// 2
func addImages() {
    for (index, imageName) in imageNamesArray.enumerated() {
        guard let image = UIImage(named: imageName) else {
            continue
        }
        imageArray.append(image)
        view.imageViews[index].image = image
    }
}
// 3
func applyGaussianBlurFilter() {
    for (index, image) in imageArray.enumerated() {
        globalQueue.async(group: filterGroup) {
            print("image blurring at index \(index) started")
            
            if let filteredImage = filter.applyGaussianBlur(originalImage: image) {
                imageArray[index] = filteredImage
                print("image at index \(index) blurred")
            }
        }
    }
    
    filterGroup.notify(queue: .main) {
        for (index, image) in imageArray.enumerated() {
            view.imageViews[index].image = image
        }
        print("UI updated with blurred images")
    }
}
// 4
func applyNoirFilter() {
    for (index, image) in imageArray.enumerated() {
        globalQueue.async(group: filterGroup) {
            print("image noir at index \(index) started")
            
            if let filteredImage = filter.applyNoir(originalImage: image) {
                imageArray[index] = filteredImage
                print("image noir at index \(index) finished")
            }
        }
    }
    
    filterGroup.notify(queue: .main) {
        for (index, image) in imageArray.enumerated() {
            view.imageViews[index].image = image
        }
        print("UI updated with noir images")
    }
}
// 5
func applyFilterChain() {
    for (index, image) in imageArray.enumerated() {
        globalQueue.async(group: filterGroup) {
            print("filter chain for image at index \(index) started")
            
            guard let filteredImage = filter.applyFilterChain(originalImage: image) else {
                print("filter chain for image at index \(index) failed")
                return
            }
            
            imageArray[index] = filteredImage
            print("filter chain for image at index \(index) finished")
        }
    }
    
    filterGroup.notify(queue: .main) {
        for (index, image) in imageArray.enumerated() {
            view.imageViews[index].image = image
        }
        print("UI updated with filtered images")
    }
}

addImages()
//applyGaussianBlurFilter()
//applyNoirFilter()
//applyFilterChain()

