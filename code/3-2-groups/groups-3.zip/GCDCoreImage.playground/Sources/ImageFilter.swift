import UIKit

public class ImageFilter {
    // 1
    let context = CIContext()
    
    public init() {}
    // 2
    public func applyGaussianBlur(originalImage: UIImage) -> UIImage? {
        guard let ciimage = CIImage(image: originalImage) else {
            return nil
        }
        return applyFilter(name: "CIGaussianBlur", params: [kCIInputImageKey: ciimage, kCIInputRadiusKey: 15.0])
    }
    // 3
    public func applyNoir(originalImage: UIImage) -> UIImage? {
        guard let ciimage = CIImage(image: originalImage) else {
            return nil
        }
        return applyFilter(name: "CIPhotoEffectNoir", params: [kCIInputImageKey: ciimage])
    }
    // 4
    private func applyFilter(name: String, params: [String: Any]) -> UIImage? {
        // 5
        guard let filter = CIFilter(name: name, withInputParameters: params),
            // 6
            let outputImage = filter.outputImage,
            // 7
            let cgiimage = context.createCGImage(outputImage, from: outputImage.extent) else {
                return nil
        }
        // 8
        return UIImage(cgImage: cgiimage)
    }
    // 9
    public func applyFilterChain(originalImage: UIImage) -> UIImage? {
        guard let ciimage = CIImage(image: originalImage) else {
            return nil
        }
        
        guard let blurFilter = CIFilter(name: "CIGaussianBlur", withInputParameters: [kCIInputImageKey: ciimage, kCIInputRadiusKey: 15.0]),
            let filteredImage = blurFilter.outputImage?.applyingFilter("CIPhotoEffectNoir"),
            let cgiimage = context.createCGImage(filteredImage, from: filteredImage.extent) else {
                return nil
        }
        
        return UIImage(cgImage: cgiimage)
    }
}
