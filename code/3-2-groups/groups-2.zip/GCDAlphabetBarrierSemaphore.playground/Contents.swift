import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

// 1
var alphabetArray = [(Int, String)]()
// 2
let firstUnicodeValue = Unicode.Scalar("A").value
// 3
let lastUnicodeValue = Unicode.Scalar("Z").value
// 7
let concurrentQueue = DispatchQueue(label: "com.e-legion.gcd", qos: .utility, attributes: .concurrent)
// 8
let dispatchGroup = DispatchGroup()
// 9
let syncQueue = DispatchQueue(label: "com.e-legion.gcd", qos: .utility, attributes: .concurrent)
// 13
let semaphore = DispatchSemaphore(value: 1)
// 5
func appendValue(value: UInt32) {
    guard let char = UnicodeScalar(value) else {
        return
    }
    
    let index = alphabetArray.last?.0 ?? 0
    let newIndex = index + 1
    alphabetArray.append((newIndex, String(describing: char)))
}
// 11
func safeAppendValue(value: UInt32) {
    guard let char = UnicodeScalar(value) else {
        return
    }
    
    syncQueue.async(flags: .barrier) {
        let index = alphabetArray.last?.0 ?? 0
        let newIndex = index + 1
        alphabetArray.append((newIndex, String(describing: char)))
    }
}
// 10
func readArray() -> [(Int, String)] {
    var array = [(Int, String)]()
    syncQueue.sync {
        array = alphabetArray
    }
    return array
}
// 14
func semaphoreAppendValue(value: UInt32) {
    guard let char = UnicodeScalar(value) else {
        return
    }
    // 15
    semaphore.wait()
    let index = alphabetArray.last?.0 ?? 0
    let newIndex = index + 1
    alphabetArray.append((newIndex, String(describing: char)))
    // 16
    semaphore.signal()
}
// 18
func readArraySemaphore() -> [(Int, String)] {
    var array = [(Int, String)]()
    semaphore.wait()
    array = alphabetArray
    semaphore.signal()
    return array
}
// 4
func appendOnMainThread() {
    for value in firstUnicodeValue...lastUnicodeValue {
        appendValue(value: value)
    }
    print(alphabetArray)
}
// 6
func appendConcurrentlyUnsafe() {
    for value in firstUnicodeValue...lastUnicodeValue {
        concurrentQueue.async(group: dispatchGroup) {
            appendValue(value: value)
        }
    }
    
    dispatchGroup.notify(queue: concurrentQueue) {
        print(alphabetArray)
    }
}
// 12
func appendConcurrentlySafe() {
    for value in firstUnicodeValue...lastUnicodeValue {
        concurrentQueue.async(group: dispatchGroup) {
            safeAppendValue(value: value)
            print("\(readArray())\n")
        }
    }
    
    dispatchGroup.notify(queue: concurrentQueue) {
        print("-------final array-------")
        print(alphabetArray)
    }
}
// 17
func appendConcurrentlySemaphore() {
    for value in firstUnicodeValue...lastUnicodeValue {
        concurrentQueue.async(group: dispatchGroup) {
            semaphoreAppendValue(value: value)
            print("\(readArraySemaphore())\n")
        }
    }
    
    dispatchGroup.notify(queue: concurrentQueue) {
        print("-------final array-------")
        print(alphabetArray)
    }
}

//appendOnMainThread()
//appendConcurrentlyUnsafe()
//appendConcurrentlySafe()
appendConcurrentlySemaphore()

