import UIKit

public typealias completionClosure = (_ image: UIImage?) -> ()

public class ImageLoader {
    public init() {}
    
    public func asyncLoad(imageName: String, completion: @escaping completionClosure) {
        let pause = Double(arc4random_uniform(5))
        DispatchQueue.main.asyncAfter(deadline: .now() + pause) {
            let image = UIImage(named: imageName)
            completion(image)
        }
    }
    
    public func syncLoad(imageName: String) -> UIImage? {
        print("start")
        let pause = arc4random_uniform(5)
        sleep(pause)
        print("end")
        return UIImage(named: imageName)
    }
}
