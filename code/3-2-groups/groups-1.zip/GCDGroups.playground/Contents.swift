import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let imageLoader = ImageLoader()
var view = ImageViews(frame: CGRect(x: 0, y: 0, width: 400, height: 400))
PlaygroundPage.current.liveView = view
let imageNamesArray = ["image1.jpg", "image2.jpg", "image3.jpg", "image4.jpg"]

// 1
let imageLoadingGroup = DispatchGroup()
// 2
var imageArray = [UIImage?]()

for (_, imageName) in imageNamesArray.enumerated() {
    // 3
    DispatchQueue.global(qos: .utility).async(group: imageLoadingGroup) {
        let image = imageLoader.syncLoad(imageName: imageName)
        print("Image loaded")
        // 4
        DispatchQueue.main.async {
            imageArray.append(image)
        }
    }
}

// 5
imageLoadingGroup.notify(queue: .main) {
    for (index, image) in imageArray.enumerated() {
        view.imageViews[index].image = image
    }
    print("UI updated")
}
