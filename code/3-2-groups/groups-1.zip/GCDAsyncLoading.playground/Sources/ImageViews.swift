import UIKit

public class ImageViews: UIView {
    public var imageViews = [UIImageView]()
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        commonInit()
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        
        commonInit()
    }
    
    private func commonInit() {
        let size = frame.size.width / 2.0
        
        imageViews.append(UIImageView(frame: CGRect(x: 0, y: 0, width: size, height: size)))
        imageViews.append(UIImageView(frame: CGRect(x: 0, y: size, width: size, height: size)))
        imageViews.append(UIImageView(frame: CGRect(x: size, y: 0, width: size, height: size)))
        imageViews.append(UIImageView(frame: CGRect(x: size, y: size, width: size, height: size)))
        
        for (_, imageView) in imageViews.enumerated() {
            imageView.contentMode = .scaleAspectFit
            self.addSubview(imageView)
        }
        
        backgroundColor = .orange
    }
}
