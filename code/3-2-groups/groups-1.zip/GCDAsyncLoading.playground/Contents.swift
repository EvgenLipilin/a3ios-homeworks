import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

// 1
let imageLoader = ImageLoader()
// 2
var view = ImageViews(frame: CGRect(x: 0, y: 0, width: 400, height: 400))
PlaygroundPage.current.liveView = view
// 3
let imageNamesArray = ["image1.jpg", "image2.jpg", "image3.jpg", "image4.jpg"]

for (index, imageName) in imageNamesArray.enumerated() {
    // 4
    DispatchQueue.global(qos: .utility).async {
        let image = imageLoader.syncLoad(imageName: imageName)
        print("Image loaded")
        DispatchQueue.main.async {
            view.imageViews[index].image = image
        }
    }
}
