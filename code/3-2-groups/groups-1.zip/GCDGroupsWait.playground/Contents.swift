import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let imageLoader = ImageLoader()
let imageNamesArray = ["image1.jpg", "image2.jpg", "image3.jpg", "image4.jpg"]
var view = ImageViews(frame: CGRect(x: 0, y: 0, width: 400, height: 400))
PlaygroundPage.current.liveView = view

let imageLoadingGroup = DispatchGroup()
var imageArray = [UIImage?]()

// 1
DispatchQueue.global(qos: .utility).async {
    for (_, imageName) in imageNamesArray.enumerated() {
        imageLoadingGroup.enter()
        
        DispatchQueue.global(qos: .utility).async {
            imageLoader.asyncLoad(imageName: imageName) {
                print("Image loaded")
                imageArray.append($0)
                
                imageLoadingGroup.leave()
            }
        }
    }
    // 2
    imageLoadingGroup.wait()
    
    DispatchQueue.main.async {
        for (index, image) in imageArray.enumerated() {
            view.imageViews[index].image = image
        }
        print("UI updated")
    }
}
