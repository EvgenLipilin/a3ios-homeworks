//
// Operation.CIFilter.swift
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit
import CoreImage

class ViewController: UIViewController {
    
    @IBOutlet var imageViewCollection: [UIImageView]!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var selectFilterButton: UIButton!
    @IBOutlet weak var processButton: UIButton!
    
    let queue = OperationQueue()
    let filter = Filters()
    
    // Исходные изображения
    let imagesArray = ["image1", "image2", "image3", "image4"].map {UIImage(named: "\($0).jpg")}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.isHidden = true
        processButton.isEnabled = false
        
        for (index, value) in imageViewCollection.enumerated() {
            value.image = imagesArray[index]
        }
    }
    
    @IBAction func selectFilterButtonPressed(_ sender: Any) {
        pickerView.isHidden = false
        processButton.isHidden = true
    }
    
    @IBAction func processButtonPressed(_ sender: Any) {
        for (index, image) in imagesArray.enumerated() {
            guard let filter = selectFilterButton.titleLabel?.text else { continue }
            let operation = FilterImageOperation(inputImage: image, filter: filter)
            
            operation.completionBlock = {
                DispatchQueue.main.async {
                    self.imageViewCollection[index].image = operation.outputImage
                }
            }
            queue.addOperation(operation)
        }
        
        queue.waitUntilAllOperationsAreFinished()
    }
}

extension ViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return filter.filterArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return filter.filterArray[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectFilterButton.setTitle(filter.filterArray[row], for: .normal)
        pickerView.isHidden = true
        processButton.isHidden = false
        processButton.isEnabled = true
    }
}
