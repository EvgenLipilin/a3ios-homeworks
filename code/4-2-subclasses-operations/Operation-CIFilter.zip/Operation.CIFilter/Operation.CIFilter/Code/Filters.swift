//
//  Filters.swift
//  Operation.CIFilter
//
//  Created by Vitaly Khodyrev on 19/04/2018.
//  Copyright © 2018 E-legion. All rights reserved.
//

import Foundation

struct Filters {

    let filterArray = ["CIPhotoEffectChrome", "CIPhotoEffectFade", "CIPhotoEffectNoir", "CIPhotoEffectProcess", "CIPhotoEffectTonal", "CIPhotoEffectTransfer", "CISepiaTone"]
}
