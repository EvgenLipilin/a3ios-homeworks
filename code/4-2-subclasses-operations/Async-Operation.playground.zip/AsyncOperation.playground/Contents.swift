import UIKit
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true

class AsyncOperation: Operation {
    
    // Определяем перечисление enum State со свойством keyPath
    enum State: String {
        case ready, executing, finished
        
        fileprivate var keyPath: String {
            return "is" + rawValue.capitalized
        }
    }
    
    var state = State.ready {
        willSet {
            willChangeValue(forKey: newValue.keyPath)
            willChangeValue(forKey: state.keyPath)
        }
        didSet {
            didChangeValue(forKey: oldValue.keyPath)
            didChangeValue(forKey: state.keyPath)
        }
    }
    
    override var isReady: Bool {
        return super.isReady && state == .ready
    }
    
    override var isExecuting: Bool {
        return state == .executing
    }
    
    override var isFinished: Bool {
        return state == .finished
    }
    
    private var _isCanceled = false {
        willSet {
            willChangeValue(forKey: "isCancelled")
        }
        didSet {
            didChangeValue(forKey: "isCancelled")
        }
    }
    
    override var isCancelled: Bool {
        get {
            return _isCanceled
        }
    }
    
    override var isAsynchronous: Bool {
        return true
    }
    
    override func start() {
        guard isCancelled == false else {
            state = .finished
            return
        }
        
        main()
        
        state = .executing
    }
    
    override func cancel() {
        _isCanceled = true
    }
}

class UsefulAsyncOperation: AsyncOperation {
    override func main() {
        DispatchQueue.global(qos: .background).async {
            // do something useful
            sleep(5)
            print("Done!")
            self.state = .finished
        }
    }
}

let userfulAsyncOperaiton = UsefulAsyncOperation()
userfulAsyncOperaiton.start()

print("Main thread finished")
