//
//  ViewController.swift
//  Operation subclass
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var graphViewsCollection: [UIView]!
    @IBOutlet weak var groupCalculation: UISwitch!
    @IBOutlet var labelCollection: [UILabel]!
    
    let queue = OperationQueue()
    let iterrationsArray = [5000, 10000, 30000, 50000]
    
    @IBAction func calculateButtonPressed(_ sender: Any) {
        for label in labelCollection {
            label.isHidden = true
        }
        
        for (index, value) in iterrationsArray.enumerated() {
            let _value = graphViewsCollection[index]
            
            // Creating operation
            let operation = ComputePiOperation(iterations: value)
            operation.completionBlock = {
                print("Operation \(index)")
                
                // Updating UI
                self.updateUI(view: _value, operation: operation)
            }
        
            queue.addOperation(operation)
            
            //Group operations
            if groupCalculation.isOn {
                queue.waitUntilAllOperationsAreFinished()
            }
            
        }
    }
    
    @IBAction func clearButtonPressed(_ sender: Any) {
        for index in iterrationsArray.indices {
            let value = graphViewsCollection[index]
            let label = labelCollection[index]
            
            // Clearing subviews
            for view in value.subviews {
                if view != label {
                 view.removeFromSuperview()
                } else {
                    view.isHidden = false
                }
            }
        }
        
        print("-------------------")
    }
    
    func updateUI(view: UIView, operation: ComputePiOperation) {
        
        DispatchQueue.main.async {
            
            for indexR in operation.redPointsArray {
                view.addSubview(indexR)
            }
            for indexB in operation.bluePointsArray {
                view.addSubview(indexB)
            }
        }
    }
    
}
