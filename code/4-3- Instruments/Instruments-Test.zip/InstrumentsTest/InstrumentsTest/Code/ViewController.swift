//
//  ViewController.swift
//  InstrumentsTest
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func startCalculationButtonPressed(_ sender: UIButton) {
        doCalculations()
    }

    func doCalculations() {
        let starDate = Date()
        for i in 1...1000000 {
            calculate(i)
        }
        print("Duration \(Date().timeIntervalSince(starDate))")
    }
    
    @discardableResult
    func calculate(_ number: Int) -> String {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .currency
        
        // Просто набор случайных вычислений
        var temp = number * number / 11
        let a = temp % 124
        temp = a * number
        
        let string = numberFormatter.string(for: temp) ?? "error"
        
        let result = "Result: " + string
        
        return result
    }
}
