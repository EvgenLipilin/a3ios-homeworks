//
//  FirstViewController.swift
//  MemoryLeaks
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
}
