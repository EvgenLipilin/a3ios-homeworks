//
//  Processor.swift
//  MemoryLeaks
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

private var cache: [String: UIImage] = [:]

class Processor {
    
    var processingFinishedHandler: (() -> Void)?
    
    func startProcessing(imageName: String = "farm.jpg") {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            if let image = cache[imageName] {
                print("Image already processed \(image)")
            } else if let image = UIImage(named: imageName) {
                UIGraphicsBeginImageContext(CGSize(width: 1000.0, height: 1000.0))
                image.draw(in: CGRect(x: 0, y: 0, width: 1000, height: 1000))
                let newImage = UIGraphicsGetImageFromCurrentImageContext()
                UIGraphicsEndImageContext()
                
                cache["\(imageName)_\(arc4random())"] = newImage
            }
            
            self.processingFinishedHandler?()
        }
    }
}
