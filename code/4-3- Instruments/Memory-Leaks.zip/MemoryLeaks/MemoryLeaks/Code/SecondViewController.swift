//
//  SecondViewController.swift
//  MemoryLeaks
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var pressMeButton: UIButton!
    var processor = Processor()
    
    @IBAction func pressMeButtonPressed(_ sender: UIButton) {
        pressMeButton.isEnabled = false
        processor.processingFinishedHandler = {
            self.pressMeButton.isEnabled = true
        }
        processor.startProcessing()
    }
}
