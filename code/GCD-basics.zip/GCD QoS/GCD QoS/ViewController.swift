//
//  ViewController.swift
//  GCD QoS
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

let count = 100

class ViewController: UIViewController {
    
    // MARK: - Life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        simpleGlobalAsyncQueue()
        globalQueuesWithDifferentQoS()
//        customSerialQueue()
//        customConcurrentAsyncQueue()
//        customConcurrentSyncQueue()
//        customConcurrentAsyncQueueWithDelay()
    }
    
    // MARK: - Private
    // 1
    private func simpleGlobalAsyncQueue() {
        DispatchQueue.global().async {
            for _ in 0..<10 {
                print("🤡")
            }
        }
    }
    // 2
    private func globalQueuesWithDifferentQoS() {
        DispatchQueue.global(qos: .background).async {
            sleep(1)
            for _ in 0..<count {
                print("background")
            }
        }
        
        DispatchQueue.global(qos: .utility).async {
            sleep(1)
            for _ in 0..<count {
                print("utility")
            }
        }
        
        DispatchQueue.global(qos: .userInitiated).async {
            sleep(1)
            for _ in 0..<count {
                print("userInitiated")
            }
        }
        
        DispatchQueue.global(qos: .userInteractive).async {
            sleep(1)
            for _ in 0..<count {
                print("userInteractive")
            }
        }
        
        DispatchQueue.main.async {
            sleep(1)
            for _ in 0..<count {
                print("🤡")
            }
        }
    }
    // 3
    private func customSerialQueue() {
        let serialQueue = DispatchQueue(label: "com.e-legion.customSerialQueue")
        serialQueue.async {
            print("A")
        }
        
        serialQueue.async {
            print("p")
        }
        
        serialQueue.async {
            print("p")
        }
        
        serialQueue.async {
            print("l")
        }
        
        serialQueue.async {
            print("e")
        }
    }
    // 4
    private func customConcurrentAsyncQueue() {
        let concurrentQueue = DispatchQueue.customConcurrentQueue()
        
        concurrentQueue.async {
            print("A")
        }
        
        concurrentQueue.async {
            print("p")
        }
        
        concurrentQueue.async {
            print("p")
        }
        
        concurrentQueue.async {
            print("l")
        }
        
        concurrentQueue.async {
            print("e")
        }
    }
    // 5
    private func customConcurrentSyncQueue() {
        let concurrentQueue = DispatchQueue.customConcurrentQueue()
        
        concurrentQueue.sync {
            print("A")
        }
        
        concurrentQueue.sync {
            print("p")
        }
        
        concurrentQueue.sync {
            print("p")
        }
        
        concurrentQueue.sync {
            print("l")
        }
        
        concurrentQueue.sync {
            print("e")
        }
    }
    
}
// 6
extension DispatchQueue {
    static func customConcurrentQueue() -> DispatchQueue {
        return DispatchQueue(label: "com.e-legion.customConcurrentQueue",
                             qos: .userInitiated,
                             attributes: .concurrent,
                             autoreleaseFrequency: .inherit,
                             target: .global(qos: .userInitiated))
    }
}
