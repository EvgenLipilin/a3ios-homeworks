//
//  ViewController.swift
//  DevTools
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var balanceLabel: UILabel!
    // 1
    private var balance = 10
    // 6
    private let syncQueue = DispatchQueue(label: "com.e-legion.syncQueue")
    
    // MARK: - Life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateBalanceLabel()
    }
    
    // MARK: - Actions
    // 2
    @IBAction func withdrawTapHandler(sender: UIButton) {
        unsafeWithdraw()
//        safeWithdraw()
    }
    // 3
    @IBAction func depositTapHandler(sender: UIButton) {
        unsafeDeposit()
//        safeDeposit()
    }
    
    // MARK: - Private
    // 4
    private func unsafeWithdraw() {
        DispatchQueue.global().async {
            let newValue = self.balance - 10
            sleep(2)
            self.balance = newValue
            DispatchQueue.main.async {
                self.updateBalanceLabel()
            }
        }
    }
    // 5
    private func unsafeDeposit() {
        let newValue = self.balance + 10
        self.balance = newValue
        self.updateBalanceLabel()
    }
    // 7
    private func safeWithdraw() {
        syncQueue.async {
            let newValue = self.balance - 10
            sleep(2)
            self.balance = newValue
            DispatchQueue.main.async {
                self.updateBalanceLabel()
            }
        }
    }
    // 8
    private func safeDeposit() {
        syncQueue.async {
            let newValue = self.balance + 10
            self.balance = newValue
            DispatchQueue.main.async {
                self.updateBalanceLabel()
            }
        }
    }
    // 10
    private func safeBalance() -> Int {
        var newValue = 0
        syncQueue.sync {
            newValue = self.balance
        }
        return newValue
    }
    
    private func updateBalanceLabel() {
        unsafeUpdateBalanceLabel()
//        safeUpdateBalanceLabel()
    }
    // 9
    private func unsafeUpdateBalanceLabel() {
        self.balanceLabel.text = "Balance: \(self.balance)$"
    }
    // 11
    private func safeUpdateBalanceLabel() {
        DispatchQueue.global(qos: .userInitiated).async {
            let balance = self.safeBalance()
            DispatchQueue.main.async {
                self.balanceLabel.text = "Balance: \(balance)$"
            }
        }
    }
}
