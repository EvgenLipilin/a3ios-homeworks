//
//  ViewController.swift
//  CoreAnimationPerformance
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    private let offset: CGFloat = 16.0
    private let text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
    private let font = UIFont.systemFont(ofSize: 17.0)
    private let imageViewFrame = CGRect(origin: CGPoint(x: 127.0, y: 40.0), size: CGSize(width: 161.0, height: 120.0))
//    private let imageViewFrame = CGRect(origin: CGPoint(x: 127.0, y: 40.0), size: CGSize(width: 160.0, height: 120.0))
    
    private lazy var imageView: UIImageView = {
        let imageView = UIImageView(frame: imageViewFrame)
        return imageView
    }()
    
    private lazy var textLabel: UILabel = {
        let label = UILabel(frame: .zero)
        label.font = font
        label.text = text
        label.numberOfLines = 0
        return label
    }()
    
    // MARK: - Life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        colorBlendedLayerExample1()
//        colorBlendedLayerExample2()
//        colorBlendedLayerExample3()
//        colorBlendedLayerExample4()
//        colorMisalignedImagesExample()
//        colorOffScreenRenderedExample1()
//        colorOffScreenRenderedExample2()
    }
    
    // MARK: - Private
    // 7
    private func boundingSizeWithNoRounding() -> CGSize {
        let maxWidth = view.frame.size.width - 2.0 * offset
        let textBlock = CGSize(width: maxWidth, height: CGFloat.greatestFiniteMagnitude)
        return text.boundingRect(with: textBlock, options: .usesLineFragmentOrigin, attributes: [NSAttributedStringKey.font: font], context: nil).size
    }
    // 8
    private func boundingSizeWithRounding() -> CGSize {
        let size = boundingSizeWithNoRounding()
        return CGSize(width: ceil(size.width), height: ceil(size.height))
    }
    
    // MARK: - Color Blended Layers
    
    private func colorBlendedLayerExample1() {
        addNonOpaqueImageView()
        addTransparentTextLabel()
    }
    
    private func colorBlendedLayerExample2() {
        addTransparentImageView()
        addTransparentTextLabel()
    }
    
    private func colorBlendedLayerExample3() {
        addOpaqueImageView()
        addOpaqueTextLabel()
    }
    
    private func colorBlendedLayerExample4() {
        addOpaqueImageViewWithNoAlphaImage()
        addOpaqueTextLabel()
    }
    
    // MARK: - Color Misaligned Images
    
    private func colorMisalignedImagesExample() {
        addOpaqueImageViewWithNoAlphaImage()
        addOpaqueTextLabelWithRoundingFrame()
    }
    
    // MARK: - Color Off-screen rendered
    
    private func colorOffScreenRenderedExample1() {
        addOpaqueImageViewWithDynamicShadow()
        addOpaqueTextLabelWithRoundingFrame()
    }
    
    private func colorOffScreenRenderedExample2() {
        addOpaqueImageViewWithStaticShadow()
        addOpaqueTextLabelWithRoundingFrame()
    }
    
    // MARK: - UIImageView
    // 1
    private func addImageView(imageName: String, opaque: Bool) {
        imageView.isOpaque = opaque
        imageView.image = UIImage(named: imageName)
        view.addSubview(imageView)
    }
    // 2
    private func addNonOpaqueImageView() {
        addImageView(imageName: "dice", opaque: false)
    }
    // 4
    private func addTransparentImageView() {
        addImageView(imageName: "dice", opaque: true)
        imageView.alpha = 0.95
    }
    // 5
    private func addOpaqueImageView() {
        addImageView(imageName: "dice", opaque: true)
    }
    
    private func addOpaqueImageViewWithNoAlphaImage() {
        addImageView(imageName: "dice_no_alpha", opaque: true)
    }
    // 10
    private func addOpaqueImageViewWithDynamicShadow() {
        addImageView(imageName: "dice_no_alpha", opaque: true)
        imageView.layer.shadowRadius = 5.0
        imageView.layer.shadowOpacity = 0.5
    }
    // 11
    private func addOpaqueImageViewWithStaticShadow() {
        addOpaqueImageViewWithDynamicShadow()
        imageView.layer.shadowPath = UIBezierPath(rect: imageView.bounds).cgPath
    }
    
    // MARK: - UILabel
    
    private func addTextLabel(frame: CGRect) {
        textLabel.frame = frame
        view.addSubview(textLabel)
    }
    // 3
    private func addTransparentTextLabel() {
        let frame = CGRect(origin: CGPoint(x: offset, y: 176.0), size: boundingSizeWithNoRounding())
        addTextLabel(frame: frame)
    }
    // 6
    private func addOpaqueTextLabel() {
        let frame = CGRect(origin: CGPoint(x: offset, y: 176.0), size: boundingSizeWithNoRounding())
        addTextLabel(frame: frame)
        textLabel.isOpaque = true
        textLabel.backgroundColor = .white
    }
    // 9
    private func addOpaqueTextLabelWithRoundingFrame() {
        let frame = CGRect(origin: CGPoint(x: offset, y: 176.0), size:boundingSizeWithRounding())
        addTextLabel(frame: frame)
        textLabel.isOpaque = true
        textLabel.backgroundColor = .white
    }
    
}
